### Contributors
Nicholas Cheung, Alec Felt, Victoria Tran

### Running on localhost
1. Navigate to webapp directory:
```bash
cd NeoMarket/WebApp
```
2. Run webapp on localhost:
```bash
npm run dev
```
3. Open new tab in browser and enter url:
```
https://localhost:3000
```
