import React from 'react'

/**
@ Alec
@ 2/20/18
@ Purpose: File for all constant data to stored and exported
**/

export const sideBarTitles = ['Wallet', 'Posts', 'Trash', 'Forums', 'Listings', 'Promos', 'Purchases', 'People']
