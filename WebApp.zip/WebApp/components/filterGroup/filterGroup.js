import React, { Component } from 'react'
import { Stylesheet } from '../stylesheet.js'

/**

@ Alec

@ Date: 2/29/18

Purpose: container for the filters

**/

class FilterGroup extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {

    }
  }

  render () {
    return (
      <div className="filterGroup">
      </div>
    )
  }
}

export default FilterGroup
